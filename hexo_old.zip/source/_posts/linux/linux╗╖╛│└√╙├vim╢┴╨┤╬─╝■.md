﻿---
title: linux环境利用vim读写文件  
date: 2018-07-03  
tags: linux  
categories: linux
---
# linux环境利用vim读写文件  
## 创建或者修改文件  
$ vim test.md  
如果该目录下不存指定文件在则新建，存在指定文件则是修改    
## 编辑文件  
按字母i进入编辑模式    
## 保存退出：  
按下ESC件退出编辑模式进入一般模式  
然后输入  
$ :wq  
## 强制不保存退出  
$ :q!  
## 直接退出：  
$ :q   
