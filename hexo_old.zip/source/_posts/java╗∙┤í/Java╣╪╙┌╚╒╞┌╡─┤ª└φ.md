---
title: Java中关于时间日期的处理  
date: 2018-06-12 17:19:18  
tags: date  
categories: 学习  
---

# 相关类：  
## Date：   
Date表示特定的瞬间，精确到毫秒，Date中的相应方法已废弃，从JDK 1.1开始，应该使用Calendar类实现日期和时间字段之间转换。  

## DateFormat：  
DateFormat是日期/时间格式化子类的抽象类，格式化并解析日期或时间，可以进行日期 -> 文本 ，文本-> 日期的转换。子类  SimpleDateFormat。   

## Calendar：   
Calendar是日历抽象类，可通过其获取日期时间。推荐使用。  

### Date类的基本使用    

public class test1 {

    public static void main(String[] args) {

        // 无参构造
        Date date = new Date();
        System.out.println(date);//Tue Jun 12 14:10:41 CST 2018
        // 带参构造
        date = new Date(System.currentTimeMillis());
        System.out.println(date);//Tue Jun 12 14:10:41 CST 2018

        // void setTime(long time) 设置 Date 对象，以表示 1970 年 1 月 1 日 00:00:00以后time毫秒的时间点
        // long getTime() 返回自 1970 年 1 月 1 日 00:00:00以来此 Date 对象表示的毫秒数
        date.setTime(1000);// 1s
        System.out.println(date);//Thu Jan 01 08:00:01 CST 1970
        System.out.println(date.getTime());//1000
    }
}  

### DateFormate类的基本使用：    

public class test2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        // 日期 -> 文本
        Date date = new Date();
        // 无参构造
        DateFormat dateFormat = new SimpleDateFormat();
        // format方法 将Date格式化为日期/时间字符串
        String time = dateFormat.format(date);
        System.out.println(time);// 18-6-12 下午2:17

        dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        // 带参构造
        String time2 = dateFormat.format(date);
        System.out.println(time2);// 2018-06-12 02:17:26

        // 文本-> 日期
        String tiem3 = "2016年5月12日  22时47分15秒";
        Date date2 = new Date();
        //格式一定要和文本格式相同  包括空格数
        DateFormat dateFormat2 = new SimpleDateFormat("yyyy年MM月dd日  hh时mm分ss秒");
        //parse()从给定字符串的开始解析文本，以生成一个日期
        try {
			date2 = dateFormat2.parse(tiem3);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        System.out.println(date2);//Thu May 12 22:47:15 CST 2016
    }


### Calendar类的基本使用： 
 
public class test3 {  
// TODO Auto-generated method stub  
  public static void main(String[] args) throws ParseException {  
        //获取功能  
        //getInstance方法返回Calendar对象，其日历字段已由当前日期和时间初始化  
        Calendar calendar=Calendar.getInstance();  
        //获取当前时间  
        Date date =calendar.getTime();  
        System.out.println(date);//Tue Jun 12 14:34:53 CST 2018     
        //获取年  
        int year=calendar.get(Calendar.YEAR);  
        //获取月,注意为当前月份-1  
        int month=calendar.get(Calendar.MONTH);   
        //获取日   
        int day=calendar.get(Calendar.DAY_OF_MONTH);  
        System.out.println(year + "-" + (month + 1) + "-" + day);//2018-6-12  

        //add功能  
        calendar.add(Calendar.YEAR, 1);  
        System.out.println(calendar.get(Calendar.YEAR));//2019
        calendar.add(Calendar.MONTH, 7);
        System.out.println(calendar.get(Calendar.MONTH));//0
        calendar.add(Calendar.DAY_OF_MONTH, -12);//由于今日就是12日，-12所以会进入前一个月
        System.out.println(calendar.get(Calendar.DAY_OF_MONTH));//31

        System.out.println(calendar.get(Calendar.YEAR)+"-"+calendar.get(Calendar.MONTH)+"-"+calendar.get(Calendar.DAY_OF_MONTH));//2019-11-31

        //set功能
        //2008年5月12日（星期一）14时28分04秒
        calendar.set(2008, 4, 12, 14, 28,04);
        System.out.println(calendar.get(Calendar.YEAR)+"-"+(calendar.get(Calendar.MONTH)+1)+"-"+calendar.get(Calendar.DAY_OF_MONTH));//2008-5-12
    }

} 
