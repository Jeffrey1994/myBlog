# 基于hexo-github个人博客搭建   
# 说明
本文基于windows10环境，未经过不同版本测试
# 基本流程  
首先安装Node.js–>安装Git–>安装Hexo–>安装主题–>本地测试运行–>配置github和coding仓库–>上传部署  
# 安装Node.js和npm
地址
https://nodejs.org/en/download/
截图
选择适合的版本自行下载安装

下载后查看是否安装成功：
node -version
npm -version

## 安装git  
sudo apt-get install git
# 安装hexo  
npm install -g hexo-cli  
ps：理论在git或者在windos控制台执行都可以，但是本人在git执行死活不行，最终选择在windows控制台执行


现在hexo基本安装完成了，下面我们本地启动看看样式


首先初始化
在桌面随便创建文件夹，然后在终端cd到文件夹，执行以下命令
hexo init # hexo 会在目标文件夹简历网站所需要的文件
npm install # 安装依赖包

本地启动
通过以下命令来在本地运行我们的博客
hexo g # 相当于 hexo generate，生成静态文件
hexo s # 相当于 hexo server，在本地服务器上运行

截图
复制以上本地地址http://localhost:4000/在浏览器中打开
截图

基本就是这样的，刚开始界面很丑，主题可以走行修改，后续文章会介绍一下主题的修改

