新下载了一个eclipse，打开之后没有server选项
在软件eclipse下的Help->InstallNew Software->中，在Work with中点击Add。

添加 ：
Name——"Kepler" repository；
Location——http://download.eclipse.org/releases/kepler，如下图所示：
![图片](https://coding.net/api/project/3009393/files/4185071/imagePreview)

点击OK，找到选项Web,XML, Java EE and OSGi Enterprise Development下JST Server AdaptersExtensions，进行勾选，如下图所示：
![图片](https://coding.net/api/project/3009393/files/4185079/imagePreview)

安装重启完就有了。