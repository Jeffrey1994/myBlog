---
title: Oracle数据库-trunc函数的用法  
date: 2018-06-12 17:19:18  
tags: oracle  
categories: study    
---
# Oracle数据库-trunc函数的用法  
trunc 函数可用于截取日期时间  
## 用法：trunc（字段名，精度） 
## 具体实例：  
当前日期：2016/10/28 15:11:58  
### 1、获取当前日期  
select trunc(sysdate) from dual;    
显示：2016/10/28  
### 2、截取时间到年时，sql语句如下：  
select trunc(sysdate,'yyyy') from dual;   
显示：2016/1/1  
### 3、截取时间到月时，sql语句： 
select trunc(sysdate,'mm') from dual;    
显示：2016/10/1  
### 4、截取时间到日时，sql语句：  
select trunc(sysdate,'dd') from dual;  
显示：2016/10/28  
### 5、截取时间到小时时，sql语句：  
select trunc(sysdate,'hh')  from dual;  
显示：2016/10/28 15:00:00  
### 6、截取时间到分钟时，sql语句：  
select trunc(sysdate,'mi') from dual;  
显示：2016/10/28 15:11:00   
### 7、截取时间到秒 暂时不知  
### 8、不可直接用trunc(sysdate,'yyyy-mm-dd')，会提示“精度说明符过多”
