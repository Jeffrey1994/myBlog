﻿---
title: Oracle修改表结构  
date: 2018-07-03  
tags: oracle  
categories: study    
---
## 创建表  
create table student(  
stu_name char(2),  
stu_age integer  
);  

## 增加列  
alter table student add stu_age integer; 

## 删除列  
alter table student drop column stu_age;  

## 修改列名  
alter table student rename  column stu_age to stu_age_new;    

## 修改类的类型  
alter table student modify stu_name varchar2(30);  

## 修改表的名字  
rename student to student1;  

## 添加备注  
comment on column student.stu_name is '备注名';  
comment on table student1 is 'student2';  

## 删除表  
drop table student2;    
