在我们运行项目前，都需要将项目部署到tomcat上，但是有时我们会遇到这种情况：项目明明存在，但是eclipse中tomcat的add and remove找不到项目，无法部署，那么这个问题该如何解决呢？

我们回到项目目录，选择缺少的文件，右击，选择最后的properties选项。也可以直接按住快捷键alt+enter。
在左侧，点击project facets。
在右边勾选如图示的三项：Dynamic Web Module、Java、JavaScript。点击apply，确认，等待更新配置结束，会自动退出。


![图片](https://coding.net/api/project/3009393/files/4184355/imagePreview)

现在我们再看tomcat的add and remove，还是没有，到此为止是网上大部分的做法，
接下来是本人挖坑之路，
首先随便写了个类，邮件run on server，报错如下：

![图片](https://coding.net/api/project/3009393/files/4184446/imagePreview)
很明显是版本不支持，升级一下tomcat即可


